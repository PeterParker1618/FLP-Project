package com.capg.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capg.bean.ThirdPartyMerchant;




@Repository
public interface ThirdPartyDao extends JpaRepository<ThirdPartyMerchant, String>{
	
	@Query("from ThirdPartyMerchant where emailid=:emailId")
	public ThirdPartyMerchant getThirdPartyId(@Param("emailId")String emailId);

}
