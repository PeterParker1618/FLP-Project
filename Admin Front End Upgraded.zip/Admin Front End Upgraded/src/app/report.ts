export class Report {

    "id": number;
    "orderId": number;
    "productId": number;
    "productCategory": String;
    "merchantId": String;
    "productStatus": String;

    // constructor(id: number, orderId: number, productId: number, productCategory: String, merchantId: String, productStatus: String){
    //     this.id = id;
    //     this.orderId = orderId;
    //     this.productId = productId;
    //     this.productCategory = productCategory;
    //     this.merchantId = merchantId;
    //     this.productStatus = productStatus;
    // }

    constructor(){}

}
