import { Component, OnInit } from '@angular/core';
import { ThirdParty } from '../third-party';
import { AdminServiceService } from '../admin-service.service';
import { Email } from '../email';

@Component({
  selector: 'app-compose-mail',
  templateUrl: './compose-mail.component.html',
  styleUrls: ['./compose-mail.component.css']
})
export class ComposeMailComponent implements OnInit {

  thirdParty:ThirdParty;
  constructor(private adminService: AdminServiceService) { }


  email: Email;

  ngOnInit() {
  }
  sendMail(fromm:string,too:string,maildata:string,name:string){
    this.email=new Email(fromm,too,maildata);
    this.adminService.sendMail(this.email).subscribe();
    if(this.adminService.getInviteTP()){
    this.thirdParty = new ThirdParty(name,too);
    console.log(this.thirdParty);
      this.adminService.inviteMerchant(this.thirdParty)
        .subscribe();
    } 
  }
}
