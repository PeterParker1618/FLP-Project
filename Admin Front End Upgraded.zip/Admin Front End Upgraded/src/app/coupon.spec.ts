import { Coupon } from './coupon';

describe('Coupon', () => {
  it('should create an instance', () => {
    expect(new Coupon()).toBeTruthy();
  });
});
