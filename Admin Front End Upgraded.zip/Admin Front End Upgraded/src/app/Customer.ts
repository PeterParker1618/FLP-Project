export class Customer {

    custId:string;
    emailId:string;
    firstName:string;
    lastName:string;
    isValid:string;
    address:string;
    phoneNo:string;
    walletBalance:number;
    cartItems:[];
    wishItems:[];

    constructor(custId:string,emailId:string,firstName:string,lastName:string,isValid:string,address:string,phoneNo:string,walletBalance:number,cartItems:[],wishItems:[])
    {
        this.custId=custId;
        this.emailId=emailId;
        this.firstName=firstName;
        this.lastName=lastName;
        this.isValid=isValid;
        this.address=address;
        this.phoneNo=phoneNo;
        this.walletBalance=walletBalance;
        this.cartItems=cartItems;
        this.wishItems=wishItems;
    }
}
