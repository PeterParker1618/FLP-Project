import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'merchantsearch'
})
export class MerchantsearchPipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
    return value.filter((data) => data.merchant.merId.indexOf(args)!==-1);
  }

}
