import { Component, OnInit } from '@angular/core';
import { ThirdParty } from '../third-party';
import { AdminServiceService } from '../admin-service.service';
import { Email } from '../email';
import { Router } from '@angular/router';

@Component({
  selector: 'app-invite-third-party-merchant',
  templateUrl: './invite-third-party-merchant.component.html',
  styleUrls: ['./invite-third-party-merchant.component.css']
})
export class InviteThirdPartyMerchantComponent implements OnInit {
  constructor(private adminService: AdminServiceService, private routes: Router) { }

  ngOnInit() {
    this.adminService.setInviteTP(true);
    this.routes.navigateByUrl("/composeMail");
  }
}
