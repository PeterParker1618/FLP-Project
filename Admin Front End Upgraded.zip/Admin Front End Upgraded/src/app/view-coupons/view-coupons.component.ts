import { Component, OnInit } from '@angular/core';
import { AdminServiceService } from '../admin-service.service';

@Component({
  selector: 'app-view-coupons',
  templateUrl: './view-coupons.component.html',
  styleUrls: ['./view-coupons.component.css']
})
export class ViewCouponsComponent implements OnInit {

  array:any[];
  constructor(private adminService:AdminServiceService) { }

  ngOnInit() {
    this.adminService.getAllCoupons().subscribe(data=>this.responseData(data))
    
  }
  responseData(response){
    this.array=response;
    console.log(this.array)
  }

}
