import { Injectable } from '@angular/core';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { OrderedItem } from './ordered-item';

@Injectable({
  providedIn: 'root'
})
export class BusinessService {
  private url: string;
  constructor(private http: HttpClient) { 
    this.url="http://localhost:8081";
  }

  public display(): Observable<OrderedItem>
    {
      return this.http.get<OrderedItem>(this.url + '/getOrderedItems')
    }

    
  public displayOrderedItems(): Observable<OrderedItem[]>
  {
    return this.http.get<OrderedItem[]>(this.url + '/getOrderedItems')
  }
  
}
