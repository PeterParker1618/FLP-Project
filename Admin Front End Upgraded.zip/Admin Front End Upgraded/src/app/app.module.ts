import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HighchartsChartModule } from 'highcharts-angular';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ShowMerchantsComponent } from './show-merchants/show-merchants.component';
import { ShowInventoryComponent } from './show-inventory/show-inventory.component';
import { ShowCustomersComponent } from './show-customers/show-customers.component';
import { ShowEmailLogComponent } from './show-email-log/show-email-log.component';

import { HttpClientModule } from '@angular/common/http';
import { PendingRequestsComponent } from './pending-requests/pending-requests.component';
import { TotalRevenueComponent } from './total-revenue/total-revenue.component';
import { AdminpageComponent } from './adminpage/adminpage.component';
import { AddDedicatedMerchantComponent } from './add-dedicated-merchant/add-dedicated-merchant.component';
import { ManageMerchantComponent } from './manage-merchant/manage-merchant.component';
import { AddThirdPartyMerchantComponent } from './add-third-party-merchant/add-third-party-merchant.component';
import { RemoveMerchantComponent } from './remove-merchant/remove-merchant.component';
import { InviteThirdPartyMerchantComponent } from './invite-third-party-merchant/invite-third-party-merchant.component';
import { SignUpMerchantComponent } from './sign-up-merchant/sign-up-merchant.component';
import { InboxEmailComponent } from './inbox-email/inbox-email.component';
import { SentMailComponent } from './sent-mail/sent-mail.component';
import { DispatchComponent } from './dispatch/dispatch.component';
import { ReportComponent } from './report/report.component';
import { FormsModule } from '@angular/forms';
import { SearchPipe } from './search.pipe';
import { MerchantsearchPipe } from './merchantsearch.pipe';
import { CategoryPipe } from './category.pipe';
import { ViewCouponsComponent } from './view-coupons/view-coupons.component';
import { CouponGenerationComponent } from './coupon-generation/coupon-generation.component';

import { ComposeMailComponent } from './compose-mail/compose-mail.component';
import { OrderedProductsComponent } from './ordered-products/ordered-products.component';
import { PlacedProductsComponent } from './placed-products/placed-products.component';
import { DispatchedProductsComponent } from './dispatched-products/dispatched-products.component';
import { DeliveryStatusComponent } from './delivery-status/delivery-status.component';
import { RefundComponent } from './refund/refund.component';
import { TpmerchantsignupComponent } from './tpmerchantsignup/tpmerchantsignup.component';
import { CategoryreportComponent } from './categoryreport/categoryreport.component';
import { MerchantreportComponent } from './merchantreport/merchantreport.component';
import { StatusComponent } from './status/status.component';


@NgModule({
  declarations: [
    AppComponent,
    ShowMerchantsComponent,
    ShowInventoryComponent,
    ShowCustomersComponent,
    ShowEmailLogComponent,
    PendingRequestsComponent,
    TotalRevenueComponent,
    AdminpageComponent,
    AddDedicatedMerchantComponent,
    ManageMerchantComponent,
    AddThirdPartyMerchantComponent,
    RemoveMerchantComponent,
    InviteThirdPartyMerchantComponent,
    SignUpMerchantComponent,
    InboxEmailComponent,
    SentMailComponent,
    DispatchComponent,
    ReportComponent,
    SearchPipe,
    MerchantsearchPipe,
    CategoryPipe,
    ViewCouponsComponent,
    CouponGenerationComponent,

    ComposeMailComponent,

    OrderedProductsComponent,

    PlacedProductsComponent,

    DispatchedProductsComponent,

    DeliveryStatusComponent,

    RefundComponent,

    TpmerchantsignupComponent,

    CategoryreportComponent,

    MerchantreportComponent,

    StatusComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    HighchartsChartModule,
    FormsModule
   
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
