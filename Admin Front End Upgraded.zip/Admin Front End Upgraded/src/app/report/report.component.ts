import { Component, OnInit } from '@angular/core';
// import { Business } from '../business';
import { BusinessService } from '../business.service';
import { AdminServiceService } from '../admin-service.service';
import { Report } from '../report';


@Component({
  selector: 'app-report',
  templateUrl: './report.component.html',
  styleUrls: ['./report.component.css']
})
export class ReportComponent implements OnInit {

  id: number;
  orderId: number;
  productId: number;
  productCategory: String;
  merchantId: String;
  productStatus: String;
  businessList = new Report();

  constructor(private businessService: AdminServiceService) { }

  ngOnInit() {
    this.businessService.getReport().subscribe((report) => {
      this.businessList = (report);
      console.log(report);
      console.log(this.businessList);
    }
    )

  }

}
