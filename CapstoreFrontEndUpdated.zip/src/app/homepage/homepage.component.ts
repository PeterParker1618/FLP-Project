import { Component, OnInit } from '@angular/core';

import { IProductDetails } from '../iproduct-details';
import { CapServiceService } from '../cap-service.service';
import { CapStoreService } from '../cap-store.service';
import { Product } from '../Product';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {

  Products: IProductDetails[];
  searchProducts: IProductDetails[]=[];
  ProductValue: any;
  ProductKey: any;
  ProductCategory: IProductDetails;
  Category: string[] = [];
  uniqueItems: any;
  ProductCatMob: IProductDetails[];
  ProductCatLap: IProductDetails[];
  ProductCatTv: IProductDetails[];
  capService: CapStoreService
  pro:IProductDetails;
  
  constructor(private productDetailsService: CapServiceService, capService: CapStoreService) {
    this.capService = capService;
   }

   
   search2(data: any){
     
    console.log(data.Search);
    
    for(let i=0; i< this.Products.length;i++){
     
      let pro = this.Products[i];
     
      if(pro.prodCategory === data.Search){
       
       this.searchProducts.push(pro);
        console.log(pro);
      break;
      }
    }
   }

 
  functionCategory() {

    console.log(this.Products);

    for (var i = 0; i < this.Products.length; i++) {

      //console.log(this.Products[3].productPrice);
      this.Category.push(this.Products[i].prodCategory);
      console.log(this.Category[i]);

    }

    this.uniqueItems = Array.from(new Set(this.Category));
    console.log(this.uniqueItems[0]);


    var j = 0;
    var ProductsAccordingCategory = {};

    for (var i = 0; i < this.uniqueItems.length; i++) {
      ProductsAccordingCategory[this.uniqueItems[i]] = new Array();
      for (var j = 0; j < this.Products.length; j++) {
        if (this.uniqueItems[i] === this.Products[j].prodCategory) {
          
          ProductsAccordingCategory[this.uniqueItems[i]].push(this.Products[j]);
        }
      }
        
    }

    console.log(ProductsAccordingCategory);
  
  }

  addToCart(data: any){
    console.log(data);
    this.pro=new IProductDetails(data.prodName,data.price,data.discount);
    this.capService.addToCart(this.pro);
  }

  addToWish(data:any){
    this.pro=new IProductDetails(data.prodName,data.price,data.discount);
    this.capService.addToWish(this.pro);
  }

  ngOnInit() {
    this.productDetailsService.getAllProducts().subscribe(
      data => {
      this.Products = data;
        this.functionCategory();
      },
      error => console.log(error));
  }

}
