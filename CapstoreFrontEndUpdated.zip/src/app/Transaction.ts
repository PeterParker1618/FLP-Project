export class Transaction {
    cardNo: Number;
    cardName: String;
    month: Number;
    year: Number;
    cvv: Number;
    amount:Number;
    constructor(cardNo: Number, cardName: String, month: Number, year: Number, cvv: Number,amount:Number) {
        this.cardNo = cardNo;
        this.cardName = cardName;
        this.month = month;
        this.year = year;
        this.cvv = cvv;
        this.amount=amount;
    }
}