import { Component, OnInit } from '@angular/core';
import { DashboardServiceService } from '../dashboard-service.service';
import { WishItem } from '../wishitem';
import { IProductDetails } from '../iproduct-details';
import { Router } from '@angular/router';
import { CapStoreService } from '../cap-store.service';
import { Cartlist } from '../cartlist';


@Component({
  selector: 'app-wishlist',
  templateUrl: './wishlist.component.html',
  styleUrls: ['./wishlist.component.css']
})
export class WishlistComponent implements OnInit {

  pro:IProductDetails[];
  router: Router;
  ser:CapStoreService;
  prod: IProductDetails;
  constructor(private service:DashboardServiceService,ser:CapStoreService,  router: Router) {
    this.router = router;
    this.ser=ser;
   }

  cartlist:Cartlist[];
  ngOnInit() {
  
    this.pro=this.ser.getWishlist();
    
  }
  deleteFromWishList(wishlist) {
    let index=this.pro.indexOf(wishlist);
    this.pro.splice(index,1);
    alert("deleted Successful!!");

  }

  addToCart(wishList:any){
    this.prod =new IProductDetails(wishList.prodName,wishList.price,wishList.discount);
    this.ser.addToCart(this.prod);
  }

}