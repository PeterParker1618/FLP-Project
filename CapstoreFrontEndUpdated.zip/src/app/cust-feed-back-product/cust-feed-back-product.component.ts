import { Component, OnInit } from '@angular/core';
import { CustomerService } from 'src/app/customer.service';
import { ProductFeedback } from 'src/app/ProductFeedback';
import { Router } from '@angular/router';


@Component({
  selector: 'app-cust-feed-back-product',
  templateUrl: './cust-feed-back-product.component.html',
  styleUrls: ['./cust-feed-back-product.component.css']
})
export class CustFeedBackProductComponent implements OnInit {
  customerservice: CustomerService;
  productfeedback: ProductFeedback;
  constructor(customerservice:CustomerService) {
this.customerservice=customerservice;
  }
  ngOnInit() {
       }
       add(data:any) {
         console.log(data);
         this.productfeedback=data;
         this.customerservice.add(this.productfeedback);
         }
       }


//   feedbackcomment:String;
//   constructor() { }
//   givefeedback(data:any) {
//     this.feedbackcomment=data.feedbackcomment;
//   }


//   ngOnInit() {
//   }

// }



// customerservice: CustomerService;
// router:Router;
// productfeedback: ProductFeedback[]=[];
// issendFeedback: boolean = true;
//   constructor(customerservice: CustomerService,router:Router) { 
//     this.customerservice=customerservice;
//   }

// sendFeedbackk(id:number)
// {
  
//   this.customerservice.sendFeedback(id);
//   this.router.navigate(['app-cust-home']);
// }

//   ngOnInit() {
//     this.customerservice.fetchDetails();
//     this.productfeedback = this.customerservice.getFeedback();
//   }

// }