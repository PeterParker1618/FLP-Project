// export class MerchantFeedback {
//     merchantId: number;
//     merchantFeedback: string;
    
    
//     constructor( merchantId: number,merchantFeedback: string) {
//     this.merchantFeedback=merchantFeedback;
//     this.merchantId=merchantId;
//     }
//     }


export class ProductFeedback{
    productId:number;
    productFeedback:string;
    productRating:number;
    constructor(productId: number,productFeedback:string,productRating:number)
    {
        this.productId=productId;
        this.productFeedback=productFeedback;
        this.productRating=productRating;
    }
}