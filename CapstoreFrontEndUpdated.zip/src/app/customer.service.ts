import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ProductFeedback } from './ProductFeedback';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
arr : ProductFeedback[] = [];
httpClient : HttpClient;

constructor(httpClient: HttpClient,router: Router) {
      this.httpClient=httpClient;
    }

    public add (productFeedback : ProductFeedback)
    {
      alert("feedback submitted successfully!!");
      //return this.httpClient.post<ProductFeedback>("http://localhost:8023/rating",productFeedback);
    }
  }
//   http: HttpClient;
//   merchantfeedback: MerchantFeedback[]=[];
//   productfeedback:ProductFeedback[]=[];
//   router: Router;

//   constructor(http: HttpClient,router: Router) {
//     this.http=http;
//    }
//    fetched:boolean=false;
//    fetchDetails()
//    {
//      this.http.get('./assets/MerchantFeedback.json')
//      .subscribe(data=>
//       {if(!this.fetched)
//         {
//           this.convert(data);
//           this.fetched=true;
//         }
//       });
//    }
//    getDetails(): MerchantFeedback[]
//    {
//      return this.merchantfeedback;
//    }


//    getFeedback(): ProductFeedback[]
//    {
//      return this.productfeedback;
//    }






//    convert(data: any) {
//     for (let o of data) {
//       let e = new MerchantFeedback(o.merchantId,o.merchantFeedback)
//       this.merchantfeedback.push(e);}
//    }
   
//   createdFlag: boolean = false;
//   createdFeedBack: MerchantFeedback;
//    sendFeedback(data: any) {
//     this.createdFeedBack=new MerchantFeedback(data.merchantId, data.merchantFeedback);
//     alert("Feedback sent Succesfully!!!");
    

//   }

//   createdFlag1: boolean = false;
//   createdFeedBackk: ProductFeedback;
//    sendFeedbackk(data: any) {
//     this.createdFeedBackk=new ProductFeedback(data.productId, data.productFeedback,data.productRating);
//     alert("Feedback sent Succesfully!!!");
    

//   }








// }
// export class MerchantFeedback {
//   merchantId: number;
//   merchantFeedback: string;
//   constructor( merchantId: number,merchantFeedback: string) {
//   this.merchantFeedback=merchantFeedback;
//   this.merchantId=merchantId;
//   }
//   }


  
// export class ProductFeedback{
//   productId:number;
//   productFeedback:string;
//   productRating:number;
//   constructor(productId: number,productFeedback:string,productRating:number)
//   {
//       this.productId=productId;
//       this.productFeedback=productFeedback;
//       this.productRating=productRating;
//   }
// }


