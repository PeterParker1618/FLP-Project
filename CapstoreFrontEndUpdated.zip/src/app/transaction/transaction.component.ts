import { Component, OnInit } from '@angular/core';
import { CapstoreService } from '../capstore.service';
import { Transaction } from '../Transaction';

@Component({
  selector: 'transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css']
})
export class TransactionComponent implements OnInit {
service:CapstoreService;
transaction:Transaction;
  constructor(service:CapstoreService) { 
    this.service=service;
  }

  ngOnInit() {
  }
  add(details:any){
    console.log(details);
   this.transaction=details;
    // this.transaction.cardName=details.cardName;
    // this.transaction.cardNo=details.cardNo;
    // this.transaction.month=details.month;
    // this.transaction.year=details.year;
    // this.transaction.cvv=details.cvv;
    this.service.add(this.transaction).subscribe(data =>{
      alert("Transaction is succesfull");
    })
  }
}
